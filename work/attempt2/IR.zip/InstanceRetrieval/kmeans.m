function [] = hikmeans( Directory, K )
	run('vlfeat-0.9.14/toolbox/vl_setup.m');
	load([Directory 'MatFiles/' 'Descriptors.mat']);
	[C,A] = vl_kmeans(single(Descriptors)',K);
	save([Directory 'MatFiles/kmeansVoc_' int2str(K) '.mat'],'C','A');
end
