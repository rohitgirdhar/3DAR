#!/bin/bash
dir=`cat dir.txt`;
list=`cat ${dir}ImageNames.txt`
for i in $list
do 
 paste ${dir}words/w_${i}.txt ${dir}keypoints/K_${i}.txt > ${dir}wordkeys/wk_$i.txt
done
