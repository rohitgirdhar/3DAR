hikmeans('/Pulsar3/jay.panda/ChhotaBheem/BheemAndGanesha/', 10, 1000);
