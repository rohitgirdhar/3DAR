matlab -nojvm -nodisplay -nosplash < $1
