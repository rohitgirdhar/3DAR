i) CallMatlabFn.sh (for hikmeans fn call)
ii) parseTree.m and quantize.m
iii) wordsInDir.m
iv) combineWordsNKeys.sh
v) BuildSearchIndex
vi) fill output_All with ImageSearch(all)
vii) run_matlab_UF.sh

