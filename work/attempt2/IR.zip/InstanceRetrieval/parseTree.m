Directory = char(textread('dir.txt','%s'));
clusters = char(textread('clusters.txt','%s'));
load([Directory 'MatFiles/VocTree_' clusters '.mat']);
recurse(tree,0,Directory);
