Directory = char(textread('dir.txt','%s'));
clusters = char(textread('clusters.txt','%s'));
name = textread([Directory 'ImageNames.txt'],'%s');
DCount = dlmread([Directory 'DCount.txt']);
W = dlmread([Directory 'Words_' clusters '.txt']);

x=1;
for i = 1:size(DCount,1)
	dlmwrite([Directory 'words/w_' char(name(i)) '.txt'], W(x:x+DCount(i)-1), 'precision',7);
	x = x+DCount(i);
end


