#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<cstdio>
#include<fstream>

using namespace std;

int main(){
   int N;
   vector< string > ImageNames;
   string tempName;
   ifstream dirPathF("dir.txt");
   string Directory;
   dirPathF >> Directory;
   dirPathF.close();
   cout << "hello1" << endl;

   N = 5062;
   string iNamesN = Directory + "ImageNames.txt";
   ifstream iNames(iNamesN.c_str(),ifstream::in);
   if( iNames.is_open() ){
        for( int i = 1 ; i <= N ; i++ ){
	    iNames >> tempName;
	    ImageNames.push_back( tempName );
	}
	iNames.close();
   }
   else{
	cout << "error opening file imageNamesList.txt" << endl;
   }
   
   cout << "hello2" << endl;
   string WordsDir = Directory + "UsefulFeatures/uf_5_";
   map < int , map< int, int > > Index;
   double temp;
   int nW;
   int vword;
   double vx, vy, va, vb, vc;
   ifstream iWords;
   for( int i = 1 ; i <= N ; i++ ){
	string fName = WordsDir +  ImageNames[i-1] + ".txt";
	cout << fName <<endl;
	iWords.open( fName.c_str() );
	if( iWords.is_open() && iWords.good() ){
	    while( !iWords.eof() && iWords.good() ){
		iWords >> vword >> vx >> vy >> va >> vb;
//		cout << "! " << vword << endl;
//		iWords >> vx >> vy ; 
		if( Index[vword].count(i) > 0 ){
			Index[vword][i] += 1;
		}
		else{
			Index[vword][i] = 1;
		}
	    }	    
	    iWords.close();
	}
   	else{
	   cout << "error opening file " << endl;
   	}
   }
   cout << "hello3" << endl;

   string indexFileN = Directory + "UF5InvertedIndexF_10K.txt";
   FILE *fp;
   fp = fopen(indexFileN.c_str(),"wb");
//   ofstream indexFile( indexFileN.c_str() ,ios::out | ios::binary);
   for( map< int, map < int, int > >::iterator it1 = Index.begin() ; it1 != Index.end() ; ++it1 ){
	vword = it1->first;
//	cout << vword << endl;
//	indexFile << vword << " " << Index[vword].size() << endl; 
//	indexFile.write( (char*)&vword, sizeof(vword) );
	fprintf( fp, "%d %d\n",vword, Index[vword].size() );
	for( map< int , int >::iterator it2 = Index[vword].begin() ; it2 != Index[vword].end() ; ++it2 ){
//	    indexFile.write( (char*)&it2->first, sizeof(it2->first) );
//	    indexFile.write( (char*)&it2->second, sizeof(it2->second) );
//	    indexFile << it2->first << " " << it2->second << endl;	    
	    fprintf( fp, "%d %d\n",it2->first, it2->second );
	}
   }
//   indexFile.close();
   fclose(fp);
}
